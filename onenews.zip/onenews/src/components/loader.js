import React, { Component } from 'react'
import spinner from './loaderCircle.gif'

const loader = () => {
    return (
      <div className="text-center">
        <img src={spinner} alt="spinner"/>
      </div>
    )
}

export default loader
