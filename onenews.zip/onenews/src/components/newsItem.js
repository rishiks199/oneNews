import React, { Component } from 'react'
import './css/newsItem.css';
const { DateTime } = require('luxon');

const newsItem = (props) => {
      let { title, description, url: newsUrl, urlToImage, author, publishedAt, source, category } = props;
      const date = DateTime.fromISO(new Date(publishedAt).toISOString(), { zone: `${'UTC+5:30'}` }).toFormat('dd-MM-yyyy,hh:mm a');
      let pillColor = 'danger';
      if(category === 'sports'){
        pillColor = 'success';
      }
    return (
        <div className="card my-3">
          <span className={`pillCard position-absolute top-0 translate-middle badge rounded-pill bg-${pillColor}`}>
    Source - {source}
  </span>
        <img src={urlToImage ? urlToImage : 'https://newsapi.org/'} className="card-img-top" alt="..."/>
        <div className="card-body">
          <h5 className="card-title">{title ? title : 'N/A'}  </h5>
          <p className="card-text">{description ? description : 'N/A'}</p>
          <p className="card-text"><small className="text-muted"> Published By <b style={{color:'black'}}>{author}</b> at <b style={{color:'black'}}>{date}</b></small></p>
          <a href={newsUrl ? newsUrl : 'https://newsapi.org/'} target="_blank" className="btn btn-primary" rel="noreferrer">View More</a>
        </div>
      </div>
    )
}

export default newsItem
