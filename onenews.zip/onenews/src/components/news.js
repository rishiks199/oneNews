import React, { Component } from 'react'
import NewsItem from './newsItem'
import Spinner from './loader';
import PropTypes from 'prop-types';
import InfiniteScroll from "react-infinite-scroll-component";

export class news extends Component {
    static defaultProps = {
        country: 'in',
        category: 'general',
        pageSize: 10,
    }
    static propTypes = {
        country: PropTypes.string,
        pageSize: PropTypes.number,
        category: PropTypes.string,
    }
    disableNextButton = false;
   pageSize;
   props;
    newUrl = `https://newsapi.org/v2/top-headlines?country=in&apiKey=a8a53a1ee50b452898fc54da367fe358`;
    constructor(props){
        super(props);
        this.props = props;
        this.state = {
            articles : [],
            page:1,
            loading : true,
            totalResults:0,
        }
        document.title = `1News - ${this.capitalizeFirstLetter(this.props.category)}`
    }
    myStyle = {
        display:'flex',
    }
    childStyle = {
        width: '30%',
    }
     capitalizeFirstLetter(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
      }
    updateNews = async() =>{
        this.setState({loading : true});
        let data = await fetch(this.newUrl.concat(`&page=${this.state.page}&pageSize=${this.props.pageSize}& category=${this.props.category}`));
        const parsedData = await data.json();
        this.setState({
            articles: parsedData.articles,
            totalResults: parsedData.totalResults,
            loading: false,
        });
    }
     componentDidMount = async() => {   
         await this.updateNews();
    }

    fetchMoreData = async() => {
        this.setState({page: this.state.page + 1})
        let data = await fetch(this.newUrl.concat(`&page=${this.state.page}&pageSize=${this.props.pageSize}& category=${this.props.category}`));
        const parsedData = await data.json();
        this.setState({
            articles: this.state.articles.concat(parsedData.articles),
            totalResults: parsedData.totalResults,
        });
      };
    // getPrevPage = async() => {
    //     this.setState({page: this.state.page - 1});
    //     this.updateNews();
    // }
    // getNextPage = async () => {
    //     this.setState({
    //         page: this.state.page + 1,
    //     });
    //     this.updateNews();
    // }
  render() {
    return (
    <div className="my-3">
        <h2 className="text-center">One News - News At your fingertips</h2>
        <p className="text-center" style={{fontFamily:'bold', fontSize:'30px',color:'blue',textDecoration:'underline'}}>Top News On {this.capitalizeFirstLetter(this.props.category)}</p>
        {this.state.loading && <Spinner/>}
        <InfiniteScroll
          dataLength={this.state.articles.length} 
          next={this.fetchMoreData}
          hasMore={this.state.articles.length !== this.state.totalResults}
          loader={<Spinner/>}
        >
        <div className="row">
        {
        !this.state.loading && this.state.articles.map((data) =>{
            return <div className="col-md-4" key={data.url} style={this.childStyle}>
            <NewsItem title={data.title ? data.title : 'N/A'} description={data.description ? data.description : 'N/A'} 
                url={data.url ? data.url : 'https://newsapi.org'} 
                urlToImage={data.urlToImage ? data.urlToImage: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a2/Transperth_Volgren_CR228L_bodied_Volvo_B7RLE.jpg/640px-Transperth_Volgren_CR228L_bodied_Volvo_B7RLE.jpg'}
                publishedAt = {data.publishedAt ? data.publishedAt : 'Unknown'}
                author ={data.author ? data.author :'Unknown'}
                source = {(data.source && data.source.name) || 'Unknown'}
                category = {this.props.category}/>
          </div>
        })}
        </div>
        </InfiniteScroll>
        
         {/* prev and next navigation button
        <div className="navigation d-flex justify-content-between">
        <button disabled={this.state.page<=1} type="button mx-2" style={{marginLeft:'30px'}} className="btn btn-info" onClick={this.getPrevPage}>&larr; Prev</button>
        <button disabled={this.state.page + 1 >= Math.ceil(this.state.totalResults / this.props.pageSize)}type="button mx-2" style={{marginRight:'30px'}} className="btn btn-info" onClick={this.getNextPage}>Next &rarr;</button>
        </div> */}
      </div>
      
    )
  }
}

export default news
