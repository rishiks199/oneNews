import React, { useState, useEffect } from 'react'
import NewsItem from './newsItem'
import Spinner from './loader';
import PropTypes from 'prop-types';
import InfiniteScroll from "react-infinite-scroll-component";

const News = (props) => {
  const [articles, setArticles] = useState([]);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [totalResults, setTotalResults] = useState(0);
  // document.title = `1News - ${capitalizeFirstLetter(props.category)}`
    let newUrl = `https://newsapi.org/v2/top-headlines?country=in&apiKey=a8a53a1ee50b452898fc54da367fe358`;
    const myStyle = {
        display:'flex',
    }
    const childStyle = {
        width: '30%',
    }
     const capitalizeFirstLetter = (string) => {
        return string.charAt(0).toUpperCase() + string.slice(1);
      }
    const updateNews = async () =>{
        props.setProgress(0);
        setLoading(true);
        let data = await fetch(newUrl.concat(`&page=${page}&pageSize=${props.pageSize}& category=${props.category}`));
        const parsedData = await data.json();
        props.setProgress(50);
        setArticles(parsedData.articles);
        setTotalResults(parsedData.totalResults);
        setLoading(false)
        props.setProgress(100);
    }

    //works same as componentDidMount for class based
    useEffect(() => {
      document.title = `${capitalizeFirstLetter(props.category)} - NewsMonkey`;
      updateNews(); 
      // eslint-disable-next-line
  }, [])

    const fetchMoreData = async() => {
        setPage(page + 1);
        let data = await fetch(newUrl.concat(`&page=${page}&pageSize=${props.pageSize}& category=${props.category}`));
        const parsedData = await data.json();
        setArticles(articles.concat(parsedData.articles));
        setTotalResults(parsedData.totalResults);
      };
    // const getPrevPage = async() => {
    //     setState({page: page - 1});
    //     updateNews();
    // }
    // const getNextPage = async () => {
    //     setState({
    //         page: page + 1,
    //     });
    //     updateNews();
    // }
    return (
      <>
    <div className="my-3">
        <h2 className="text-center" style={{marginTop:'90px'}}>One News - News At your fingertips</h2>
        <p className="text-center" style={{fontFamily:'bold', fontSize:'30px',color:'blue',textDecoration:'underline'}}>Top News On {capitalizeFirstLetter(props.category)}</p>
        {loading && <Spinner/>}
        <InfiniteScroll
          dataLength={articles.length} 
          next={fetchMoreData}
          hasMore={articles.length !== totalResults}
          loader={<Spinner/>}
        >
        <div className="row">
        {
        articles.map((data) =>{
            return <div className="col-md-4" key={data.url} style={childStyle}>
            <NewsItem title={data.title ? data.title : 'N/A'} description={data.description ? data.description : 'N/A'} 
                url={data.url ? data.url : 'https://newsapi.org'} 
                urlToImage={data.urlToImage ? data.urlToImage: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a2/Transperth_Volgren_CR228L_bodied_Volvo_B7RLE.jpg/640px-Transperth_Volgren_CR228L_bodied_Volvo_B7RLE.jpg'}
                publishedAt = {data.publishedAt ? data.publishedAt : 'Unknown'}
                author ={data.author ? data.author :'Unknown'}
                source = {(data.source && data.source.name) || 'Unknown'}
                category = {props.category}/>
          </div>
        })}
        </div>
        </InfiniteScroll>
        
         {/* prev and next navigation button
        <div className="navigation d-flex justify-content-between">
        <button disabled={page<=1} type="button mx-2" style={{marginLeft:'30px'}} className="btn btn-info" onClick={getPrevPage}>&larr; Prev</button>
        <button disabled={page + 1 >= Math.ceil(totalResults / props.pageSize)}type="button mx-2" style={{marginRight:'30px'}} className="btn btn-info" onClick={getNextPage}>Next &rarr;</button>
        </div> */}
      </div>
      </>
      
    )
}

News.defaultProps = {
  country: 'in',
  category: 'general',
  pageSize: 10,
}
News.propTypes = {
  country: PropTypes.string,
  pageSize: PropTypes.number,
  category: PropTypes.string,
}
export default News
