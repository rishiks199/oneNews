import React, {useState} from 'react'
import Navbar from './components/navbar'
import TextForm from './components/textForm';
import Alert from './components/alerts';
import About from './components/about'
import './App.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";

function App() {
  const [mode, setMode] = useState('light');
  const [alert, setAlert] = useState(null);
  const switchMode = () => {
    if(mode === 'light'){
      setMode('dark')
      document.body.style.backgroundColor ='#1e0a2e';
      showAlert("Dark Mode Enabled","success");
    } else {
      setMode('light');
      document.body.style.backgroundColor ='white';
      showAlert("Light Mode Enabled","success")
    } 
  }
  const showAlert = (message, type) => {
    setAlert({message, type});
    setTimeout(() =>{
      setAlert(null);
    }, 1000);
  }
  return (
    <>
   <Alert alert = {alert}/>
    <BrowserRouter>
    <Navbar mode = {mode} switchMode={switchMode}/>
  <Routes>
         <Route path="/" element={<TextForm heading="Enter the text" mode = {mode} showAlert = {showAlert}/>} />
          <Route path="about" element={<About />} />
  </Routes>
        </BrowserRouter>
    </>
    );
  // return (
  //   <>
  //  <Navbar mode = {mode} switchMode={switchMode}/>
  //  <Alert alert = {alert}/>
  //   <div className="container my-3">
  //   <TextForm heading="Enter the text" mode = {mode} showAlert = {showAlert}/>
  //   <About />
  //       </div>
  //   </>
  //   );
}

export default App;
