import React from 'react'

function alerts(props) {
    const convertFirstCharToUpperCase = (word) => {
        return word.charAt(0).toUpperCase() + word.slice(1, word.length);
    }
  return (
    props.alert && <div className={`alert alert-${props.alert.type} alert-dismissible fade show`} style={{textAlign: 'center'}} role="alert">
  <strong >{convertFirstCharToUpperCase(props.alert.type)}: </strong>{props.alert.message}
    </div>
  )
}

export default alerts
