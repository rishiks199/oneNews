const express = require('express');
const User = require('../models/User');
const { body, validationResult } = require('express-validator');
const bcrypt = require('bcrypt');
var jwt = require('jsonwebtoken');
const { fetchUserByToken } = require('../middleware/fetchUserByToken')
const router = express.Router();
const { JWT_SECRET } = require('../config');

router.post('/signUp',[
    body('name','Please Enter Valid Name').isLength({min:3}),
    body('password','Please Enter Valid Password').isLength({min:5}),
    body('email','Please Enter Valid Email').isEmail(),
],async (req, res) => {
    console.log(req.body);
    let success = false;
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success, errors: errors.array() });
    }
    let user = await User.findOne({ email: req.body.email }); 
    if(user) res.status(400).json({ success, error: 'Email Already exists. Please enter a new email address' });
    const salt = await bcrypt.genSalt(10);
    const secPassword = await bcrypt.hash(req.body.password, salt);
    try{
       user = await User.create({
        name: req.body.name,
        password: secPassword,
        email: req.body.email,
      })
      const authToken = jwt.sign({ id: user.id }, JWT_SECRET);
      success = true;
      res.status(200).json({success, token: authToken, message:'SignUp Successfull'});
    } catch(err){ 
        console.log(err);
        res.status(500).json({ success, message: 'Error Occured', error: err});
    }
});

router.post('/login',[
    body('password','Please Enter Valid Password').exists(),
    body('email','Please Enter Valid Email').isEmail(),
], async (req, res) => {
    let success = false;
    //validationResult will give all the errors as an arry
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success, errors: errors.array() });
    }    
    const { email, password } = req.body;
    console.log(req.body);
    try{
        const user = await User.findOne({email});
        if(!user) {
            return res.status(400).json({ success, error: 'Email not registered with us.' });
        }
        const passwordCompared = await bcrypt.compare(password, user.password);
        if(!passwordCompared) {
            return res.status(400).json({ success, error: 'Please enter correct credentials.' });
        }
        const authToken = jwt.sign({ id: user.id }, JWT_SECRET);
        success = true;
        res.status(200).json({success,user, token: authToken, message:'Login Success!'});

    }catch(err){
        console.log('Error',err);
        res.status(500).json({ success, errors: err.message });
    }

});

router.post('/getUser',fetchUserByToken, async(req, res) => {

    console.log('user',req.user);
    const userId = req.user.id;
    console.log('userId', userId);
    try {
        const user = await User.findById(userId).select("-password");
        res.send(user);
    }catch(err) {
        console.log('Error--', err);
        res.status(500).json({message: err.message});
    }
})


module.exports = router;