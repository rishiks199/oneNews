const express = require('express');
const router = express.Router();
const Notes = require('../models/Notes');
const { body, validationResult } = require('express-validator');
const { fetchUserByToken } = require('../middleware/fetchUserByToken')

router.get('/getAllNotes', fetchUserByToken, async (req, res) => {

    const notes = await Notes.find({ user: req.user.id, is_deleted: false });
    const totalCount = await Notes.count({ user: req.user.id, is_deleted: false });
    res.status(200).send({ count: totalCount, notes });
});

router.post('/addNotes', fetchUserByToken, [
    body('title', 'Please Enter Title').exists(),
    body('description', 'Please Enter Description').exists(),
], async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    const { title, description, tag } = req.body;
    try {
        const notesData = {
            title,
            description,
            user: req.user.id,
        };
        if (tag) notesData.tag = tag;

        const notesToSave = new Notes(notesData);
        const createdNotes = await notesToSave.save();
        res.json(createdNotes);
    } catch (err) {
        console.log(err.message);
        res.status(500).send('Internal Server Error');
    }


})

router.put('/updateNote/:id', fetchUserByToken, async (req, res) => {

    const { title, description, tag } = req.body;
    try {
        const notesData = {};
        if (title) notesData.title = title;
        if (description) notesData.description = description;
        if (tag) notesData.tag = tag;
        let note = await Notes.findById(req.params.id);
        if (!note) res.status(404).send({ message: 'Notes Not Found' });

        if (note.user.toString() !== req.user.id) res.status(401).send({ message: 'Unauthorized Access' });
        note = await Notes.findByIdAndUpdate({ _id: req.params.id, is_deleted: false }, { $set: notesData }, { new: true });
        res.status(200).send({ note: note, message: 'Updated successfully' });
    } catch (err) {
        console.log(err.message);
        res.status(500).send('Internal Server Error');
    }


})

router.put('/deleteNote/:id', fetchUserByToken, async (req, res) => {

    try {
        let note = await Notes.findById(req.params.id);
        if (!note) res.status(404).send({ message: 'Notes Not Found' });

        if (note.user.toString() !== req.user.id) res.status(401).send({ message: 'Unauthorized Access' });
        note = await Notes.findByIdAndUpdate({ _id: req.params.id }, { $set: { is_deleted: true } });
        res.status(200).send({ note: note, Success: 'Note Deleted successfully' });
    } catch (err) {
        console.log(err.message);
        res.status(500).send('Internal Server Error');
    }


})

router.get('/search', fetchUserByToken, async (req, res) => {

    try {
        const { searchQuery } = req.query;
        const criteria = {
            user: req.user.id,
            is_deleted: false,
        };
        if(searchQuery) {
            criteria.description = new RegExp(searchQuery, 'i');
        }
        const notes = await Notes.find(criteria);
        const totalCount = await Notes.count(criteria);
        // AttachedDriver.find(criteria, projection, options)
        if (!notes) res.status(404).send({ message: 'Notes Not Found' });
        res.status(200).send({ notes, totalCount });
    } catch (err) {
        console.log(err.message);
        res.status(500).send('Internal Server Error');
    }


})
module.exports = router;