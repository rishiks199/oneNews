const mongoose = require('mongoose');

const mongoURI = 'mongodb://127.0.0.1:27017/notebook?readPreference=primary&appname=MongoDB%20Compass&directConnection=true&ssl=false';

const server = 'localhost:2701';
const docName = 'notebook';
const connectToMongoDB = async() =>{
    try{    
        await mongoose.connect(mongoURI);
        console.log('Connected to MongoDB');
    }catch(err){ console.log('Error connecting to MongoDB',err);}

}

module.exports = connectToMongoDB;