
const JWT_SECRET = 'fJ8EPiNx56KafrP';

module.exports = {
    JWT_SECRET
}