module.exports = {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
  };
  