const mongoose = require('mongoose');
const opts = require('./opts');
const { Schema } = mongoose;
 
const NotesSchema = new Schema({
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    title: { type: String, required: true},
    description: { type: String, required: true},
    tag: { type: String, default:'General'},
    date: {type: Date, default: Date.now()},
    is_deleted: { type:Boolean, default: false},
}, { timestamps :opts });

const Notes = mongoose.model('Notes', NotesSchema);
Notes.createIndexes();
module.exports =  Notes;