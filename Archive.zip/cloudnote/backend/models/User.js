const mongoose = require('mongoose');
const opts = require('./opts');
const {Schema} = mongoose;
 
const UserSchema = new Schema({
    name: { type: String, required: true},
    password: { type: String, required: true},
    email: { type: String, required: true, unique: true},
    date: {type: Date, default: Date.now()},
}, { timestamps: opts });

const User = mongoose.model('User', UserSchema);
User.createIndexes();
module.exports =  User;