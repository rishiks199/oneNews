var jwt = require('jsonwebtoken');
const { JWT_SECRET } = require('../config');

const fetchUserByToken = (req, res, next) => {
    const token = req.header('auth-token');
    if(!token) res.status(401).send({error: 'Invalid token'});
    try{
        const data = jwt.verify(token, JWT_SECRET);
        req.user = data;
        next();
    } catch(err){
        res.status(401).send({error: 'Please Authenticate using a Valid token'});
    }
}

module.exports = {
    fetchUserByToken
};