import React, { useEffect, useState, useContext } from 'react';
// eslint-disable-next-line no-unused-vars
import { Link, useLocation, useNavigate } from "react-router-dom";
import { DebounceInput } from 'react-debounce-input';
import NoteContext from '../context/NoteContext';

export default function Navbar(props) {
  let location = useLocation();
  let navigate = useNavigate();
  const context = useContext(NoteContext);
  const authToken = localStorage.getItem('auth-token');
  const [query, setQuery] = useState({ query: null });
  const { search } = context;
  useEffect(() => {
    // console.log(location.pathname)
  }, [location]);
  const onChange = (e) => {
    setQuery({ query: e.target.value });
    console.log('query', query)
    search(e.target.value);
  }
  const Logout = () => {
    localStorage.removeItem('auth-token');
    navigate('/login');
  }
  return (
    <>
      <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
        <div className="container-fluid">
          <Link className="navbar-brand fs-3" to="/">Cloudnote</Link>
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="nav-item">
                <Link className={`nav-link ${location.pathName === '/' ? 'active' : ''} fs-6`} aria-current="page" to="/">Home</Link>
              </li>
              <li className="nav-item">
                <Link className={`nav-link ${location.pathName === '/textChanger' ? 'active' : ''} fs-6`} to="/textChanger">Text Changer</Link>
              </li>
              <li className="nav-item">
                <Link className={`nav-link ${location.pathName === '/about' ? 'active' : ''} fs-6`} to="/about">About</Link>
              </li>
            </ul>
            <form className="d-flex" role="search">
              {
                !authToken && <><Link className="btn btn-primary mx-2" to="/login" role="button">Login</Link>
                  <Link className="btn btn-primary mx-2" to="/signup" role="button">Signup</Link></>
              }
              {
                authToken && <>
                  <DebounceInput className="form-control mr-sm-2 mx-2" debounceTimeout={1000} onChange={onChange} placeholder="Search" />
                  <Link className="btn btn-primary mx-2" to="/profile" role="button">Profile</Link>
                  <button className="btn btn-primary mx-2" onClick={Logout}>Logout</button>
                </>
              }
            </form>
          </div>
        </div>
      </nav>
    </>
  )
}