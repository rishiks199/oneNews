import React, { useContext} from 'react'
import NoteContext from '../context/NoteContext';

function Alert() {
    const context = useContext(NoteContext);
    const { alert } = context;
    const convertFirstCharToUpperCase = (word) => {
        return word.charAt(0).toUpperCase() + word.slice(1, word.length);
    }
  return (
    <div style={{height:'50px'}}>
    {alert && <div className={`alert alert-${alert.type} alert-dismissible fade show`} style={{textAlign: 'center'}} role="alert">
  <strong >{convertFirstCharToUpperCase(alert.type)}: </strong>{alert.message}
    </div>}
    </div>
  )
}

export default Alert
