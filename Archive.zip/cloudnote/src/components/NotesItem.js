import React, { useContext } from 'react'
import NoteContext from '../context/NoteContext';

const NotesItem = (props) => {
    const context = useContext(NoteContext);
    const { deleteNote } = context;
    // const callDeleteMethod = (_id) => {
    //     deleteNote(_id);
    // }
    const { openEditModal } = props;
    const {_id, title, description, tag } = props.note;
  return (
      <div className="card mx-3 my-3" style={{width: '18rem'}}>
  <div className="card-body my-3">
      <div className="d-flex">
  <span className="position-absolute top-0 start-50 translate-middle badge rounded-pill bg-danger">{tag}</span>
    <h5 className="card-title"> {title}</h5>
    <div className="icons" style={{marginLeft: '1rem'}}>
    <i className="fa-solid fa-trash" onClick={()=>{deleteNote(_id)}}></i>
    <i className="fa-solid fa-file-pen mx-3" onClick={()=>{openEditModal(props.note)}}></i>
    </div>
    </div>
    <p className="card-text">{description}</p>
  </div>
</div>
  )
}

export default NotesItem
