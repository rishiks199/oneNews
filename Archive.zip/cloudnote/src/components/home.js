import React from 'react'
import Notes from './Notes';

export default function Home() {
  return (
    <>
     <div className="my-3">
          <Notes />
        </div>
    </>
  )
}
