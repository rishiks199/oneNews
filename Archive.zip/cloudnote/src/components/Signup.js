import React, {useState, useContext} from 'react'
import NoteContext from '../context/NoteContext';
import {useNavigate } from "react-router-dom";

function Signup() {
  let navigate = useNavigate();
  const [creds, setCredentials] = useState({name:'', email: '', password: '', conf_password: ''});
  const context = useContext(NoteContext);
  const { signup, showAlert } = context;
  const SubmitSignup = async(e) => {
      e.preventDefault();
      const result = await signup(creds.name, creds.email, creds.password);
      if(result.success) {
        navigate('/');
        showAlert('Account Created Successfully', 'success');
      }else{
        showAlert('SignUp Failed. Please try again','danger');
      }
  }
  const onChange = (e) => {
    setCredentials({...creds, [e.target.name]: e.target.value})
  }
  const formStyle={
    display: 'flex',
    flexDirection: 'column',
    textAlign: 'center',
    alignItems: 'center'
  }
  return (
    <div>
      <h2 className="text-center text-info font-weight-bold">Create Account for Cloudnote</h2>
      <form style={formStyle} onSubmit={SubmitSignup}>
      <div className="w-25 mb-3">
            <label htmlFor="name" className="form-label">Name</label>
            <input type="text" className="form-control" id="name" name = "name" aria-describedby="email" value={creds.name}  onChange={onChange} required />
          </div>
          <div className="w-25 mb-3">
            <label htmlFor="login" className="form-label">Email</label>
            <input type="text" className="form-control" id="email" name = "email" aria-describedby="email" value={creds.email}  onChange={onChange} required />
          </div>
          <div className="w-25 mb-3">
            <label htmlFor="password" className="form-label">Password</label>
            <input type="password" className="form-control" id="password" name = "password" value={creds.password} onChange={onChange} minLength={5} required />
          </div>
          <div className="w-25 mb-3">
            <label htmlFor="conf_password" className="form-label">Confirm Password</label>
            <input type="password" className="form-control" id="conf_password" name = "conf_password" value={creds.conf_password} onChange={onChange} minLength={5} required />
          </div>
          <button type="submit" className="btn btn-primary">Signup</button>
        </form>
    </div>
  )
}

export default Signup
