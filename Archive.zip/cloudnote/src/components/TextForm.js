import React, {useState, useEffect } from 'react';
import {useNavigate } from "react-router-dom";

export default function TextForm(props) {
    const [text,setText] = useState('');
    const disabled = (text.length === 0);
    const colorProp = {
        backgroundColor: props.mode === 'dark' ? '#3f5e8a': 'white',
        color: props.mode === 'dark' ? 'white': 'black',
    };
    let navigate = useNavigate();
    useEffect(()=>{
        if(!localStorage.getItem('auth-token')){
            navigate('/login');
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
      },[]);
    const convertToUpperCase = () =>{
        console.log('fired'+text);
        let newText = text.toUpperCase();
        setText(newText);
        props.showAlert("Text converted to Upper Case","success")
    }
    const convertToLowerCase = () =>{
        console.log('fired'+text);
        let newText = text.toLowerCase();
        setText(newText);
        props.showAlert("Text converted to Lower Case","success")
    }
    const onChangeType = (event)=>{
        console.log('onChangeType');
        setText(event.target.value);
    }
    const copyText = ()=>{
        navigator.clipboard.writeText(text)
        props.showAlert("Text copied Successfully","success");
    }
    const clearAll = () => {
       setText('');
       props.showAlert("Text field cleared Successfully","success");
    }
    const removeSpaces = () => {
        let newText = text.split(/[ ]+/);
        setText(newText.join(" "));
        props.showAlert("White spaces removed Successfully","success");
    }
    
    return (
    <>
    <div className="parent" style={{color: props.mode === 'dark' ? '#dbff0b': 'black'}}>
    <div className="container">
    <div className="mb-3">
            <h2>{props.heading}</h2>
            <textarea className="form-control" id="myBox" style={colorProp} value = {text} onChange={onChangeType}rows="6"></textarea>
        </div><button disabled= {disabled} style={{cursor: "pointer"}} className="btn btn-primary mx-2" onClick = {convertToUpperCase}>Convert Text to Upper Case</button>
        <button disabled= {disabled} className="btn btn-primary mx-2 my-2" onClick = {convertToLowerCase}>Convert Text to Lower Case</button>
        <button disabled= {disabled} className="btn btn-primary mx-2 my-2" onClick = {copyText}>Copy to Clipboard</button>
        <button disabled= {disabled} className="btn btn-primary mx-2 my-2" onClick = {removeSpaces}>Remove Spaces</button>
        <button disabled= {disabled} className="btn btn-primary mx-2 my-2" onClick = {clearAll}>Clear</button>
        </div>
        <div className="container">
            <h2>Words Count: {(text.split(' ').filter((element) => {return element.length!==0}).length) || 0}</h2>
            <h2>Character Count: {text.length}</h2>
        </div>
        </div>
        </>
    )
}