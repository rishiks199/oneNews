import React, { useContext} from 'react'
import NoteContext from '../context/NoteContext';
const { DateTime } = require('luxon');

function Profile() {
    const context = useContext(NoteContext);
    const { user } = context;
    const {name, email, created_at } = user;
    const date = DateTime.fromISO(new Date(created_at).toISOString(), { zone: `${'UTC+5:30'}` }).toFormat('dd-MM-yyyy,hh:mm a');
  return (
      <>
    <div>
      { <div className="col-md-9  text-center admin-content" id="profile">
                <div className="panel panel-info" style={{margin: '1em' }}>
                    <div className="panel-heading">
                        <h3 className="panel-title">Name</h3>
                    </div>
                    <div className="panel-body">
                        {name ? name : null}
                    </div>
                </div>
                <div className="panel panel-info" style={{margin: '1em' }}>
                    <div className="panel-heading">
                        <h3 className="panel-title">Email</h3>
                    </div>
                    <div className="panel-body">
                    {email ? email : null}
                    </div>
                </div>
                <div className="panel panel-info" style={{margin: '1em' }}>
                    <div className="panel-heading">
                        <h3 className="panel-title">Account Created At</h3>

                    </div>
                    <div className="panel-body">
                        {date ? date: null}
                    </div>
                </div>

            </div>
}
    </div>
    </>
  )
}

export default Profile
