/* eslint-disable no-dupe-keys */
/* eslint-disable no-unused-vars */
/* eslint-disable no-mixed-operators */
/* eslint-disable prefer-const */
/* eslint-disable eqeqeq */
/* eslint-disable no-prototype-builtins */
/* eslint-disable no-param-reassign */
/* eslint-disable no-shadow */
/* eslint-disable no-plusplus */
/* eslint-disable no-console */
/* eslint-disable no-await-in-loop */
/* eslint-disable object-curly-newline */
/* eslint-disable max-len */
/* eslint-disable camelcase */
/* eslint-disable no-restricted-syntax */
/* eslint-disable no-underscore-dangle */
/* eslint-disable prefer-destructuring */
import React, {useContext, useEffect, useRef, useState} from 'react';
import NoteContext from '../context/NoteContext';
import NotesItem from './NotesItem';
import AddNote from '../components/addNote';
// import EditNote from '../components/EditNote';
import {useNavigate } from "react-router-dom";

function Notes() {
    const ref = useRef(null);
    const refClose = useRef(null);
    let navigate = useNavigate();
    const context = useContext(NoteContext);
    const {notes, getAllNotes, editNote} = context;
    const [note, setNote] = useState({id:'', new_title: '', new_description:'', new_tag: ''});
    useEffect(()=>{
      if(localStorage.getItem('auth-token')){
        getAllNotes();
      }else{
        navigate('/login');
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    },[]);
    const onChange = (e) => {
        setNote({...note, [e.target.name]: e.target.value})
    }
const openEditModal= (currentNote) => {
    ref.current.click();
    const {_id, title, description, tag} = currentNote;
    setNote({id:_id, new_title: title, new_description: description, new_tag: tag});
}

const updateOnClick = () => {
    editNote(note);
    refClose.current.click(); // this will trigger when click on update
}
  return (
      <>
    <AddNote/>
        {/* <!-- Button trigger modal --> */}
<button type="button" ref= {ref} className="btn btn-primary d-none" data-bs-toggle="modal" data-bs-target="#exampleModal">
  Launch demo modal
</button>

{/* <!-- Modal --> */}
<div className="modal fade" id="exampleModal" tabIndex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div className="modal-dialog">
    <div className="modal-content">
      <div className="modal-header">
        <h1 className="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
        <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div className="modal-body">
      <form>
          <div className="mb-3">
            <label htmlFor="new_title" className="form-label">Title</label>
            <input type="text" className="form-control" id="new_title" name = "new_title" aria-describedby="new_title" value = {note.new_title} onChange={onChange} />
          </div>
          <div className="mb-3">
            <label htmlFor="new_description" className="form-label">Description</label>
            <input type="text" className="form-control" id="new_description" name = "new_description" value = {note.new_description} onChange={onChange} />
          </div>
          <div className="mb-3 w-25">
            <label htmlFor="new_tag" className="form-label">Tag</label>
            <input type="text" className="form-control" id="new_tag" name = "new_tag" value = {note.new_tag} onChange={onChange} />
          </div>
        </form>
      </div>
      <div className="modal-footer">
        <button ref={refClose} type="button" className="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" className="btn btn-primary" onClick={updateOnClick}>Update Note</button>
      </div>
    </div>
  </div>
</div>
    <div className="row my-3" style={{marginLeft: '55px'}}>
        <h2>Save Notes</h2>
        <p className="text-danger">
        {notes.length===0 && 'No Notes Available'}
        </p>
        {
            notes.map((note) =>{
                return <NotesItem key ={note._id} openEditModal = {openEditModal} note = {note} />;
            })
        }
    </div>
    </>
  )
}

export default Notes
