import React, {useState, useContext} from 'react'
import NoteContext from '../context/NoteContext';
import {useNavigate } from "react-router-dom";

function Login() {
  let navigate = useNavigate();
  const [creds, setCredentials] = useState({email: '', password: ''});
  const context = useContext(NoteContext);
  const { login, showAlert } = context;
  const SubmitLogin = async(e) => {
      e.preventDefault();
      const result = await login(creds.email, creds.password);
      console.log(result);
      if(result.success) {
        navigate('/');
        showAlert('LoggedIn Successfully', 'success');
      }else{
        showAlert('Login Failed. Please try again','danger');
      }
  }
  const onChange = (e) => {
    setCredentials({...creds, [e.target.name]: e.target.value})
  }
  const formStyle={
    display: 'flex',
    flexDirection: 'column',
    textAlign: 'center',
    alignItems: 'center'
  }
  return (
    <div>
      <h2 className="text-center text-info font-weight-bold">Login to Continue to Cloudnote</h2>
      <form style={formStyle} onSubmit={SubmitLogin}>
          <div className="w-25 mb-3">
            <label htmlFor="login" className="form-label">Email</label>
            <input type="text" className="form-control" id="email" name = "email" aria-describedby="email" value={creds.email}  onChange={onChange} />
          </div>
          <div className="w-25 mb-3">
            <label htmlFor="password" className="form-label">Password</label>
            <input type="password" className="form-control" id="password" name = "password" value={creds.password} onChange={onChange} />
          </div>
          <button type="submit" className="btn btn-primary">Login</button>
        </form>
    </div>
  )
}

export default Login
