/* eslint-disable no-dupe-keys */
/* eslint-disable no-unused-vars */
/* eslint-disable no-mixed-operators */
/* eslint-disable prefer-const */
/* eslint-disable eqeqeq */
/* eslint-disable no-prototype-builtins */
/* eslint-disable no-param-reassign */
/* eslint-disable no-shadow */
/* eslint-disable no-plusplus */
/* eslint-disable no-console */
/* eslint-disable no-await-in-loop */
/* eslint-disable object-curly-newline */
/* eslint-disable max-len */
/* eslint-disable camelcase */
/* eslint-disable no-restricted-syntax */
/* eslint-disable no-underscore-dangle */
/* eslint-disable prefer-destructuring */
import axios from "axios";
import Login from './components/Login';
import Signup from './components/Signup'
import Navbar from './components/navbar';
import About from './components/about';
import Home from './components/home';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import NoteContext from './context/NoteContext';
import Alert from './components/Alert';
import Profile from './components/Profile';
import { useState } from 'react';
import TextForm from './components/TextForm';
import './App.css';
function App() {

const apiURL = 'http://localhost:2000';
const axiosCall = async(method, url, headers, data) => {
  return new Promise((resolve, reject) => {
    axios({ method, url, headers, data })
    .then((response) => {
      resolve(response) 
    })
    .catch((err) => {
      reject(err);
    });
  });
};
 const initialNotes = [];
const [notes, setNotes] = useState(initialNotes);
const [alert, setAlert] = useState(null);
const [user, setUser] = useState(null);
//dark mode code
const [mode, setMode] = useState('light');
  const switchMode = () => {
    if(mode === 'light'){
      setMode('dark')
      document.body.style.backgroundColor ='#1e0a2e';
      showAlert("Dark Mode Enabled","success");
    } else {
      setMode('light');
      document.body.style.backgroundColor ='white';
      showAlert("Light Mode Enabled","success")
    } 
  }
  //darkMode ends here
const showAlert = (message, type) => {
  setAlert({message, type});
  setTimeout(() => {
    setAlert(null);
  },1500);
}

const signup = async(name, email, password) => {  
  const url = `${apiURL}/api/auth/signUp`;
  const data = {
    name,
    email,
    password,
  };
  const headers = {
   contentType: 'application/json'
  };
  const response = await axiosCall('POST', url, headers, data);
  if(response.data.success) {
    localStorage.setItem('auth-token',response.data.token);
    return {success: true};
  }else{
    return {success: false};
  }
};

const login = async(email, password) => {  
  const url = `${apiURL}/api/auth/login`;
  const data = {
    email,
    password,
  };
  const headers = {
   contentType: 'application/json'
  };
try{
  const response = await axiosCall('POST', url, headers, data);
  console.log('res',response);
  if(response.data.success) {
    localStorage.setItem('auth-token',response.data.token);
    setUser(response.data.user);
    return {success: true};
  }else{
    return {success: false};
  }
} catch (e) {
  return {success: false};
}
};

const getAllNotes = async() => {
  const url = `${apiURL}/api/notes/getAllNotes`;
  const headers = {
    'auth-token': localStorage.getItem('auth-token')
  };
  const response =  await axiosCall('GET', url, headers);
  // console.log('getData', response);
  setNotes(response.data.notes);
}

const addNote = async(title, description, tag) =>{
  const url = `${apiURL}/api/notes/addNotes`;
  const data = {
    title,
    description,
  };
  if(tag) data.tag = tag;
  const headers = {
    'auth-token': localStorage.getItem('auth-token')
  };
  const response = await axiosCall('POST', url, headers, data);
  // console.log('response', response);
  await getAllNotes();
  // setNotes(notes.concat(obj));
}
const deleteNote = async(itemId) =>{
  const filteredNotes = notes.filter((val)=>{return val._id!==itemId});
  setNotes(filteredNotes);
  const url = `${apiURL}/api/notes/deleteNote/${itemId}`;
  const headers = {
    'auth-token': localStorage.getItem('auth-token'),
  };
  const response =  await axiosCall('PUT', url, headers);
   console.log('delData', response);
  if(response.status === 200){
    showAlert('Note Deleted Successfully', 'success');
  }
}
const editNote = async(currentNote) =>{
  // console.log('editNote',currentNote)
  const {id, new_title: title, new_description: description, new_tag: tag } = currentNote;
  const url = `${apiURL}/api/notes/updateNote/${id}`;
  const data = {};
  if(title) data.title = title;
  if(description) data.description = description;
  if(tag) data.tag = tag;
  const headers = {
    'auth-token': localStorage.getItem('auth-token')
  };
  // console.log('data',data);
  const response = await axiosCall('PUT', url, headers, data);
  const copyNote = JSON.parse(JSON.stringify(notes));
  for(let index = 0; index < copyNote.length; index++){
      const currVal = copyNote[index];
      if(currVal._id === id) {
        copyNote[index].title = title;
        copyNote[index].description = description;
        copyNote[index].tag = tag;
        break
      }
  }
  setNotes(copyNote);
  // console.log('response', response);
  // await getAllNotes();
}

const search = async(query) => {
  const url = `${apiURL}/api/notes/search?searchQuery=${query}`;
  const headers = {
    'auth-token': localStorage.getItem('auth-token')
  };
  const response =  await axiosCall('GET', url, headers);
  // console.log('getData', response);
  setNotes(response.data.notes);
}
  return (
    <>
    <NoteContext.Provider value={{notes, setNotes,signup, login, addNote, deleteNote, editNote, getAllNotes, showAlert, alert, user, search}}>
        <BrowserRouter>
          <Navbar mode = {mode} switchMode={switchMode}/>
          <Alert/>
          <Routes>
            <Route exact path="/" element={<Home />} />
            <Route exact path="/about" element={<About />} />
            <Route exact path="/login" element={<Login />} />
            <Route exact path="/signup" element={<Signup />} />
            <Route exact path="/profile" element={<Profile />} />
            <Route path="/textChanger" element={<TextForm heading="Enter the text" mode = {mode} showAlert = {showAlert}/>} />
          </Routes>
        </BrowserRouter>
      </NoteContext.Provider>
      </>
  );
}

export default App;
