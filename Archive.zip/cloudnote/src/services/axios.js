import axios from 'axios';

const axiosCall = async(method, url, headers, data) => {
    return new Promise((resolve, reject) => {
      axios({ method, url, headers, data })
      .then((response) => {
        resolve(response) 
      })
      .catch((err) => {
        reject(err);
      });
    });
  };

  module.exports = {
      axiosCall
  }