import NoteContext from './NoteContext';

const NoteState = (props) => {
    const state = {
        "name": "Rishi",
        "age": 12,
    };
    // console.log('context', NoteContext);
    <NoteContext.Provider value={state}>
        { props.children }
    </NoteContext.Provider>

};

export default NoteState;