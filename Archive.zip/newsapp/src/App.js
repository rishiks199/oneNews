import React, { Component } from 'react'
import Navbar from './components/navbar'
import './App.css';
import News from './components/news';
import { BrowserRouter, Routes, Route } from "react-router-dom";

export default class App extends Component {
  name = 'Rishi App';
  render() {
    return (
      <div>
         <BrowserRouter>
        <Navbar/>
        <Routes>
        <Route path="/" element={<News pageSize={10} category='general' country='in'/>} /> 
        <Route path="/business" element={<News pageSize={10} category='business' country='in'/>} /> 
        <Route path="/entertainment" element={<News pageSize={10} category='entertainment' country='in'/>} /> 
        <Route path="/general" element={<News pageSize={10} category='general' country='in'/>} /> 
        <Route path="/health" element={<News pageSize={10} category='health' country='in'/>} /> 
        <Route path="/science" element={<News pageSize={10} category='science' country='in'/>} /> 
        <Route path="/sports" element={<News pageSize={10} category='sports' country='in'/>} /> 
        <Route path="/technology" element={<News pageSize={10} category='technology' country='in'/>} /> 
        </Routes>
        </BrowserRouter>
      </div>
    )
  }
}


