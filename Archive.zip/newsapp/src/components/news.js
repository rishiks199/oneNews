import React, { Component } from 'react'
import NewsItem from './newsItem'
import Spinner from './loader';
import PropTypes from 'prop-types';
export class news extends Component {
    static defaultProps = {
        country: 'in',
        category: 'general',
        pageSize: 10,
    }
    static propTypes = {
        country: PropTypes.string,
        pageSize: PropTypes.number,
        category: PropTypes.string,
    }
    disableNextButton = false;
   pageSize;
    newUrl = `https://newsapi.org/v2/top-headlines?country=in&apiKey=a8a53a1ee50b452898fc54da367fe358`;
    constructor(){
        super();
        this.disableNextButton = false;
        this.state = {
            articles : [],
            page:1,
            loading : false
        }
    }
     componentDidMount = async() => {
         this.setState({loading : true});
        let data = await fetch(this.newUrl+`&page=1&pageSize=${this.props.pageSize}&category=${this.props.category}`);
        const parsedData = await data.json();
        this.setState({
            articles: parsedData.articles,
            page: 1,
            totalResults: parsedData.totalResults,
            loading: false,
        });
    }
  myStyle = {
        display:'flex',
    }
    childStyle = {
        width: '30%',
    }
    getPrevPage = async() => {
        this.setState({loading : true});
        let data = await fetch(this.newUrl.concat(`&page=${this.state.page - 1} & pageSize=${this.props.pageSize}& category=${this.props.category}`));
        const parsedData = await data.json();
        this.setState({
            articles: parsedData.articles,
            page: this.state.page - 1,
            loading: false,
        });
    }
    getNextPage = async() => {
        console.log('getPrevPage');
        this.setState({loading : true});
        const showNextPage = (this.state.page >= Math.ceil(this.state.totalResults / 20));
        this.disableNextButton = (this.state.page + 1 > Math.ceil(this.state.totalResults / 20));
        if(showNextPage) {
            this.disableNextButton = true;
        }
        else{
            let data = await fetch(this.newUrl.concat(`&page=${this.state.page + 1} & pageSize=${this.props.pageSize}& category=${this.props.category}`));
        const parsedData = await data.json();
        this.setState({
            articles: parsedData.articles,
            page: this.state.page + 1,
            loading: false,
        });
    }
    }
  render() {
    return (
    <div className="my-3">
        <h2 className="text-center">One News - News At your fingertips</h2>
        {this.state.loading && <Spinner/>}
        <div className="row">
        {
        !this.state.loading && this.state.articles.map((data) =>{
            return <div className="col-md-4" key={data.url} style={this.childStyle}>
            <NewsItem title={data.title ? data.title : 'N/A'} description={data.description ? data.description : 'N/A'} url={data.url ? data.url : 'https://newsapi.org'} urlToImage={data.urlToImage ? data.urlToImage: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a2/Transperth_Volgren_CR228L_bodied_Volvo_B7RLE.jpg/640px-Transperth_Volgren_CR228L_bodied_Volvo_B7RLE.jpg'}/>
          </div>
        })}
        </div>
        <div className="navigation d-flex justify-content-between">
        <button disabled={this.state.page<=1} type="button mx-2" style={{marginLeft:'30px'}} className="btn btn-info" onClick={this.getPrevPage}>&larr; Prev</button>
        <button disabled={this.disableNextButton}type="button mx-2" style={{marginRight:'30px'}} className="btn btn-info" onClick={this.getNextPage}>Next &rarr;</button>
        </div>
      </div>
    )
  }
}

export default news
