import React, { Component } from 'react'

export class newsItem extends Component {
  render() {
      let { title, description, url: newsUrl, urlToImage } = this.props;
    return (
        <div className="card my-3" style={{margin:'10px 10px 10px 10px'}}>
        <img src={urlToImage ? urlToImage : 'https://newsapi.org/'} className="card-img-top" alt="..."/>
        <div className="card-body">
          <h5 className="card-title">{title ? title : 'N/A'}</h5>
          <p className="card-text">{description ? description : 'N/A'}</p>
          <a href={newsUrl ? newsUrl : 'https://newsapi.org/'} target="_blank" className="btn btn-primary" rel="noreferrer">View More</a>
        </div>
      </div>
    )
  }
}

export default newsItem
